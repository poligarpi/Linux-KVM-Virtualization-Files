#
# Original author: Rokas Kupstys <rokups@zoho.com>
# Heavily modified by: Danny Lin <danny@kdrag0n.dev>
#
# This hook uses the `cset` tool to dynamically isolate and unisolate CPUs using
# the kernel's cgroup cpusets feature. While it's not as effective as
# full kernel-level scheduler and timekeeping isolation, it still does wonders
# for VM latency as compared to not isolating CPUs at all. Note that vCPU thread
# affinity is a must for this to work properly.
#
# Original source: https://rokups.github.io/#!pages/gaming-vm-performance.md
#
# Target file locations:
#   - $SYSCONFDIR/hooks/qemu.d/vm_name/prepare/begin/cset.sh
#   - $SYSCONFDIR/hooks/qemu.d/vm_name/release/end/cset.sh
# $SYSCONFDIR is usually /etc/libvirt.
#

TOTAL_CORES='0-23'
TOTAL_CORES_MASK=FFFFFF         # 0-7, bitmask 0b11111111
HOST_CORES='9-11,21-23'         # Cores reserved for host
HOST_CORES_MASK=E00E00          # 0,4, bitmask 0b00010001
VIRT_CORES='0-8,12-20'          # Cores reserved for virtual machine(s)

VM_NAME="$1"
VM_ACTION="$2/$3"
VM="winPass10"

if [[ $1 == "$VM" ]]
then
    case $2.$3 in

        "prepare.begin")
            echo "+cpuset" | sudo tee /sys/fs/cgroup/cgroup.subtree_control
            echo "+cpuset" | sudo tee /sys/fs/cgroup/user.slice/cgroup.subtree_control
            echo "+cpuset" | sudo tee /sys/fs/cgroup/system.slice/cgroup.subtree_control
            echo "+cpuset" | sudo tee /sys/fs/cgroup/init.scope/cgroup.subtree_control
            echo "$HOS_CORES" | sudo tee /sys/fs/cgroup/user.slice/cpuset.cpus
            echo "$HOS_CORES" | sudo tee /sys/fs/cgroup/system.slice/cpuset.cpus
            echo "$HOS_CORES" | sudo tee /sys/fs/cgroup/init.scope/cpuset.cpus
        ;;

        "release.end")
            echo "$TOTAL_CORES" | sudo tee /sys/fs/cgroup/user.slice/cpuset.cpus
            echo "$TOTAL_CORES" | sudo tee /sys/fs/cgroup/system.slice/cpuset.cpus
            echo "$TOTAL_CORES" | sudo tee /sys/fs/cgroup/init.scope/cpuset.cpus
            echo "-cpuset" | sudo tee /sys/fs/cgroup/user.slice/cgroup.subtree_control
            echo "-cpuset" | sudo tee /sys/fs/cgroup/system.slice/cgroup.subtree_control
            echo "-cpuset" | sudo tee /sys/fs/cgroup/init.scope/cgroup.subtree_control
            echo "-cpuset" | sudo tee /sys/fs/cgroup/cgroup.subtree_control
        ;;

    esac
fi

